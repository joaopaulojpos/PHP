<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
  <body>
    <h1>Estamos aprendendo PHP!</h1>
    <?php
      echo "Vamos prosseguir aprendendo PHP"; 
    ?>

    <?php
  echo "Oi, Eu serei visto na sua tela";
  //Eu não! Sou apenas um comentário.
 
  echo "Oi, Eu também serei visto por você";
  # Já eu não serei!
 
  echo "E eu aqui novamente na sua tela, rs";
  /* Eu não aparecerei na sua tela novamente
  pois sou um comentário */
?>
  </body>
</html>